package com.doggo.doggydaycare.interfaces;

/**
 * Created by Meghan on 4/26/17.
 */
public interface LogInScreenInteraction
{
    void LoginStatus(String status);
    void NetworkingFlagUpdate(Boolean busyNetworking);
}
