package com.doggo.doggydaycare.interfaces;

/**
 * Created by Meghan on 4/24/2017.
 */
public interface HomeScreenInteraction
{
    void changeFragment(String fragment_name);
}
