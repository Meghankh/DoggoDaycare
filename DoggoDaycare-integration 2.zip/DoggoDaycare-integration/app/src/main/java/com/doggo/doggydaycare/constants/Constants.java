package com.doggo.doggydaycare.constants;

/**
 * Created by Meghan on 3/1/2017.
 */
public class Constants {
    public static String STATUS_LOGGED_IN = "online";
    public static String STATUS_OFFLINE = "offline";
    public static String STATUS_RELOGIN = "relogin";
}