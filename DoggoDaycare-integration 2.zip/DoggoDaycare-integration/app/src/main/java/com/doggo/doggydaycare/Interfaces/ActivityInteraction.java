package com.doggo.doggydaycare.interfaces;

/**
 * Created by Meghan on 4/26/17.
 */
public interface ActivityInteraction
{
    void InitiateLoginActivity();
}
